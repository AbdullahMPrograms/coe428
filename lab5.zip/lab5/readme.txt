All requirements of the lab are working as expected.

Q1)
I would modify the char detection algorithm. 

After detecting the tag ">" check if the character to the left of it is a "/" and if it is, then it is a stand-alone tag.

In this case it is not necessary to push it into the stack.