int heapDelete();
void addHeap(int thing2add);
int heapSize();
int getHeapElement(int index);