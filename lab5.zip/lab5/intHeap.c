#include <stdlib.h>
#include <stdio.h>
/**
 *  The functions in this module implement a Heapdata structure
 *  of integers.
 */
static int heap[100];
static int size = 0;

void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

void heapifyUp(int index) {
    int parent = (index - 1) / 2;
    if (index > 0 && heap[parent] < heap[index]) {
        swap(&heap[parent], &heap[index]);
        heapifyUp(parent);
    }
}

void heapifyDown(int index) {
    int largest = index;
    int left = 2 * index + 1;
    int right = 2 * index + 2;

    if (left < size && heap[left] > heap[largest])
        largest = left;

    if (right < size && heap[right] > heap[largest])
        largest = right;

    if (largest != index) {
        swap(&heap[index], &heap[largest]);
        heapifyDown(largest);
    }
}

/**
 * heapDelete() removes the biggest integer in the heap and returns it.
 *
 */

int heapDelete() {
    if (size == 0) {
        fprintf(stderr, "Error: Heap is empty.\n");
        return -1;
    }

    int max = heap[0];
    heap[0] = heap[--size];
    heapifyDown(0);

    return max;
}

/**
 *  addHeap(thing2add) adds the "thing2add" to the Heap.
 *
 */
void addHeap(int thing2add) {
    if (size >= 100) {
        fprintf(stderr, "Error: Heap is full.\n");
        return;
    }

    heap[size++] = thing2add;
    heapifyUp(size - 1);
}

int getHeapElement(int index) {
    if (index >= 0 && index < size)
        return heap[index];
    return -1;
}

/**
 * heapSize() returns the number of items in the Heap.
 *
 */
int heapSize()
{
    return size;
}
