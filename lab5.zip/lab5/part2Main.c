#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "intHeap.h"
#include "intStack.h"

void printHeapAsXML(int index) {
    if (index >= heapSize())
        return;

    int left = 2 * index + 1;
    int right = 2 * index + 2;

    printf("<node id=\"%d\">", getHeapElement(index));

    if (left < heapSize())
        printHeapAsXML(left);

    if (right < heapSize())
        printHeapAsXML(right);

    printf("</node>");
}

int main(int argc, char * argv[]) {
    int value;
    while (scanf("%d\n", &value) != EOF) {
        fprintf(stderr, "READING INPUT: %d\n", value);
        addHeap(value);
    }

    if (heapSize() > 0)
        printHeapAsXML(0);

    printf("\n");
    while (heapSize() > 0) {
        int value = heapDelete();
        printf("%d\n", value);
        push(value);
    }

    while (!isEmpty()) {
        int value = pop();
        printf("%d\n", value);
    }

    exit(0);
}