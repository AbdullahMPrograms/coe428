int pop();
void push(int thing2push);
int isEmpty();

