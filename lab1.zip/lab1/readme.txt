All requirements are working, 
testSort has been split into two files, testSort2 contains sortMain2.c allowing for arguments to be passed to be sorted

Q&A:
1)
void mySort(int data[], unsigned int num_elements) {
    betterSort(data, 0, num_elements-1);
}
