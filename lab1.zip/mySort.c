void mySort(int d[], unsigned int n)
{
}
