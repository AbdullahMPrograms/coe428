All requirements are working, 

Q&A:
1) The first recursive call to towers() will be invoked as: towers(4,2,1).
2) Five tower() recursive calls will be made before the first recursive call returs to the initial invocation.
3) "2 3", indicating a move from Tower 2 to Tower 3.
4) The second recursive call to towers() will be invoked as: towers(4,1,3).
5) 255. The number of moves required to solve the Hanoi problem is 2^n - 1, where n is the number of disks. As n=8, the number of moves is: 2^8 - 1 = 255.