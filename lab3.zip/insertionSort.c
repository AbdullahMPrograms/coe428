#include "mySort.h"

void mySort(int array[], unsigned int first, unsigned int last)
    {
    }
